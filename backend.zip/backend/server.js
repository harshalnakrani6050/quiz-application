import express from 'express';
import morgan from 'morgan';
import cors from 'cors';
import mongoose from 'mongoose'; // Import mongoose
import dotenv from 'dotenv'; // Import dotenv for configuration
import router from './router/route.js';

// Initialize dotenv to read configuration from .env file
dotenv.config();

const app = express();

/** App middlewares */
app.use(morgan('tiny'));  // Tiny logger format
app.use(cors());
app.use(express.json());

/** MongoDB connection */
mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1/crud_node", {
    dbName: "quiz_app", // Change database name to remove the space
  })
  .then(() => console.log("MongoDB is Connected..!"))
  .catch((err) => console.log("MongoDB Connection Error:", err.message));

/** Port */
const port = process.env.PORT || 5000;  // Use the port from environment or fallback to 5000

/** Routes */
app.use('/api', router);  // APIs route

/** Basic GET request */
app.get('/', (req, res) => {
  try {
    res.json("Get Request");
  } catch (error) {
    res.json({ error: error.message });
  }
});

/** Start server only when MongoDB connection is successful */
mongoose.connection.once('open', () => {
  app.listen(port, () => {
    console.log(`Server connected to http://localhost:${port}`);
  });
});
